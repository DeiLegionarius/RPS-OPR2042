import neopixel
from machine import ADC, Pin, PWM
from time import sleep
import time
from NP_MatrixBase import Matrix
import NP_MatrixCustom as npmc
from CustomTimer import Timer

COLOR = {
    "BLANK": (0, 0, 0),
    "WHITE": (255, 255, 255),
    "RED": (255, 0, 0),
    "GREEN": (0, 255, 0),
    "BLUE": (0, 0, 255)
}

def simultaneous_SS_Flash(matrix, names, cooldown, reps):
    for rep in range(reps):
        for key in matrix.layouts.keys():
                if key in names:
                    matrix.layouts[key].clean()
        matrix.neo.write()
        sleep(cooldown)
        for key in matrix.layouts.keys():
                if key in names:
                    matrix.layouts[key].drawNumber(matrix.layouts[key].currentNumber, COLOR["WHITE"], write=False, force=True)
        matrix.neo.write()
        sleep(cooldown)


def convertTime(minutes):
    return minutes // 60, minutes % 60

def drawClockTime(matrix, time):
    time = convertTime(time)
    matrix.applyByType("SevenSegment", "clean")
    matrix.layouts["ClockHours"].drawNumber(f"{time[0]:02d}", COLOR["WHITE"], force=True)
    matrix.layouts["ClockMinutes"].drawNumber(f"{time[1]:02d}", COLOR["WHITE"], force=True)
    matrix.neo.write()

def playAlarm(buzzer, alarm):
    while True:
        print("playing")
        for freq, duration, pause in alarm:
            buzzer.freq(freq)
            buzzer.duty(512)
            sleep(duration/1000)
            buzzer.duty(0)
            sleep(pause/1000)

def clockProtocol(matrix, buttons, buzzer, alarmSound, speed=1):
    STATE = "DEFAULT"
    ALARM_TIME = None
    DEF_previous = -60000
    CURRENT_TIME = 1430
    ALARM = False

    # Timers
    DEFAULT_Timer = Timer(60/speed)
    SET_ALARM_Timer = Timer(0.2)
    BUTTON_Timer = Timer(0.4)

    while True:
        if DEFAULT_Timer.check():
                CURRENT_TIME += 1
                if CURRENT_TIME == 1440:
                    CURRENT_TIME = 0  

        if STATE == "DEFAULT":
            drawClockTime(matrix, CURRENT_TIME)

            if CURRENT_TIME == ALARM_TIME and ALARM:
                playAlarm(buzzr, alarmSound)

            
            if not buttons["OK"].value():
                if BUTTON_Timer.check():
                    STATE = "SET_ALARM"    

        elif STATE == "SET_ALARM":
            preTime = 0
            refreshRate = 0.2
            ALARM_TIME = 0
            substate = 1

            drawClockTime(matrix, ALARM_TIME)
            matrix.layouts["ClockHours"].flashNumber("00", COLOR["WHITE"], 0.2, 3)

            while True:
                if SET_ALARM_Timer.check():
                    drawClockTime(matrix, ALARM_TIME)

                if not buttons["OK"].value():
                    if BUTTON_Timer.check():
                        if substate == 1:
                            substate -= 1
                            matrix.layouts["ClockMinutes"].flashNumber("00", COLOR["WHITE"], 0.2, 3)
                        else:
                            break
                if not buttons["UP"].value():
                    if BUTTON_Timer.check():
                        ALARM_TIME += (5 + (55*substate))
                if not buttons["DOWN"].value():
                    if BUTTON_Timer.check():
                        ALARM_TIME -= (5 + (55*substate))
                
                if ALARM_TIME >= 1440:
                    ALARM_TIME -= 1440
                elif ALARM_TIME < 0:
                    ALARM_TIME += 1440
                
            simultaneous_SS_Flash(matrix, ("ClockHours", "ClockMinutes"), 0.2, 3)
            STATE = "DEFAULT"
            ALARM = True

    return




if __name__ == "__main__":
    matrix = Matrix(27, 23, 7)
    buttons = {
        "OK": Pin(33, Pin.IN, Pin.PULL_UP),
        "UP": Pin(26, Pin.IN, Pin.PULL_UP),
        "DOWN": Pin(25, Pin.IN, Pin.PULL_UP)
    }
    buzzer = PWM(Pin(32))
    alarm = [
        (523, 180, 70),
        (659, 180, 70),
        (784, 260, 120),

        (659, 180, 60),
        (784, 180, 60),
        (1047, 350, 150),

        (784, 180, 60),
        (659, 180, 60),
        (523, 250, 100),
        (1047, 400, 250),
    ]
    # playAlarm(buzzer, alarm)

    SSD1 = matrix.createLayout("ClockHours", "SevenSegment", len_digits=2, start=(0, 0))
    SSD2 = matrix.createLayout("ClockMinutes", "SevenSegment", len_digits=2, start=(14, 0))
    SSDIV = matrix.createLayout("SSDIV", "SSDivider", start=(11, 0))


    SSD1.drawNumber("00", COLOR["WHITE"], write=True)
    SSDIV.draw(COLOR["WHITE"], write=True)
    SSD2.drawNumber("00", COLOR["WHITE"], write=True)

    clockProtocol(matrix, buttons, buzzer, alarm, speed=100)
