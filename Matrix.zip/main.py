import neopixel
from machine import ADC, Pin
from time import sleep
import time
from NP_MatrixBase import Matrix
import NP_MatrixCustom as npmc

COLOR = {
    "BLANK": (0, 0, 0),
    "WHITE": (255, 255, 255),
    "RED": (255, 0, 0),
    "GREEN": (0, 255, 0),
    "BLUE": (0, 0, 255)
}

def convertTime(minutes):
    return minutes // 60, minutes % 60
    
        
def potToSSdisplay(pot, matrix, refreshRate=0.5, endCondition=(None, False)):
    preTime = 0

    while True:
        if time.ticks_ms() > preTime + (refreshRate * 1000):
            matrix.cleanDisplay()

            potValue = pot.read()
            #potValue = TREBA DODELAT
            matrix.drawNumber(potValue, "WHITE", write=True)
            preTime = time.ticks_ms()
        
        if endCondition[0]:
            if (not endCondition[1] and endCondition[0]()) or (endCondition[1] and not endCondition[0]()):
                matrix.cleanDisplay()
                return potValue


def clockProtocol(matrix, pot, buttons, speed=1):
    STATE = "DEFAULT"
    ALARM_TIME = None
    DEF_previous = -60000
    CURRENT_TIME = 1430

    #matrix.drawDivider("WHITE")
    while True:
        if STATE == "DEFAULT":
            if time.ticks_ms() > DEF_previous + (60000/speed):
                DEF_previous = time.ticks_ms()
                CURRENT_TIME += 1
                if CURRENT_TIME == 1440:
                    CURRENT_TIME = 0
                displayTime = convertTime(CURRENT_TIME)
                displayTime = int(f"{displayTime[0]:02d}{displayTime[1]:02d}")
                #matrix.cleanDisplay()
                #matrix.drawNumber(displayTime, "WHITE", write=True)

        elif STATE == "SET_ALARM":
            ALARM_TIME = potToSSdisplay(pot, matrix, endCondition=(buttons["OK"].value, True))
            #matrix.flashNumber(ALARM_TIME, "WHITE", 0.2, 5)
            STATE = "DEFAULT"

        # Input queue
        if not buttons["OK"].value() and STATE == "DEFAULT":
            STATE = "SET_ALARM"




if __name__ == "__main__":
    protocol = 2

    if protocol == 1:
        matrix = Matrix(27, 23, 7)
        pot = ADC(Pin(34))
        buttons = {
            "OK": Pin(33, Pin.IN, Pin.PULL_UP)
        }
        clockProtocol(matrix, pot, buttons, speed=100)

    elif protocol == 2:
        matrix = Matrix(27, 23, 7)
        SSD1 = npmc.SevenSegment(len_digits=2, parent=matrix, start=(0, 0))
        SSDIV = npmc.SSDivider(parent=matrix, start=(9, 0))
        SSD2 = npmc.SevenSegment(len_digits=2, parent=matrix, start=(12, 0))
        matrix.addLayout("SSD1", SSD1)
        matrix.addLayout("SSD2", SSD2)
        matrix.addLayout("SSDIV", SSDIV)

        SSD1.drawNumber(88, COLOR["WHITE"], write=True)
        SSDIV.draw(COLOR["WHITE"], write=True)
        SSD2.drawNumber(88, COLOR["WHITE"], write=True)
    