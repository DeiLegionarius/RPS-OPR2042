class Layout:
    def __init__(self, kwargs):
        self.parent = kwargs["parent"]
        self.border = kwargs["border"] # ((x,y)(x,y))
        if not self.isValid(kwargs["req_border"]):
            raise ValueError("Invalid layout boundaries")

    def isValid(self, reqBorder):
        b = self.border
        if self.parent.length < b[1][0] or self.parent.length < b[1][1]:
            return False
        elif b[0][0] < 0 and b[0][1] < 0:
            return False
        elif (b[1][0] - b[0][0] > reqBorder[0] or b[1][1] - b[0][1] > reqBorder[1]):
             return False
        else:
            return True
    
    def isInArea(self, foreignBorder):
        if foreignBorder[0][0] > self.border[0][0] and foreignBorder[0][1] > self.border[0][1]:
            return True
        elif foreignBorder[1][0] > self.border[1][0] and foreignBorder[1][1] > self.border[1][1]:
            return True
        else:
            return False

class SevenSegment(Layout):
    LINES = [((1, 0), (2, 0)), ((0, 1), (0, 2)), ((3, 1), (3, 2)), ((1, 3), (2, 3)), ((0, 4), (0, 5)), ((3, 4), (3, 5)), ((1, 6), (2, 6))]

    NUMBERS = [(0, 1, 2, 4, 5, 6), (2, 5), (0, 2, 3, 4, 6), (0, 2, 3, 5, 6), (1, 3, 5, 2), (0, 1, 3, 5, 6), (0, 1, 3, 4, 5, 6), (0, 2, 5), (0, 1, 2, 3, 4, 5, 6), (0, 1, 2, 3, 5, 6)]

    def __init__(self, **kwargs): # len_digits, parent, start
        self.lengthDigits = kwargs["len_digits"]
        self.start = kwargs["start"]
        kwargs["req_border"] = kwargs["len_digits"] * 5, 7
        kwargs["border"] = (self.start[0], self.start[1]), (self.start[0]+(5*kwargs["len_digits"]), self.start[1]+7)
        super().__init__(kwargs)

        self.currentNumber = None
        

    def setLineColor(self, digit, lineNum, color):
        lineCoords = SevenSegment.LINES[lineNum]
        start = (digit * 5) + self.start[0]
        self.parent.setPixelColor((lineCoords[0][0] + start, lineCoords[0][1]), color)
        self.parent.setPixelColor((lineCoords[1][0] + start, lineCoords[1][1]), color)

    def drawDigit(self, digit, value, color):
        valueSequence = SevenSegment.NUMBERS[value]
        for num in valueSequence:
            self.setLineColor(digit, num, color)

    def drawNumber(self, value: int, color: str, write=False):
        valueStr = str(value)
        if self.currentNumber == value or len(valueStr) > self.lengthDigits:
            return
        self.currentNumber = value
        for i in range(len(valueStr)):
            val = int(valueStr[i])
            offset = self.lengthDigits - len(valueStr)
            self.drawDigit(i + offset, val, color)

        if write: self.parent.neo.write()
        print(("should have written", value))

    def clean(self):
        self.drawNumber(int("8"*self.lengthDigits), "BLANK", write=True)
    
    def flashNumber(self, num, color, delay, reps):
        for i in range(reps):
            self.clean()
            sleep(delay)
            self.drawNumber(num, "WHITE", write=True)

class SSDivider(Layout):
    def __init__(self, **kwargs): # start
        kwargs["req_border"] = 3, 7
        self.start = kwargs["start"]
        kwargs["border"] = (self.start[0], self.start[1]), (self.start[0]+3, self.start[1]+7)
        super().__init__(kwargs)

    def draw(self, color, write=True):
        self.parent.setPixelColor((self.start[0]+1, self.start[1]+2), color)
        self.parent.setPixelColor((self.start[0]+1, self.start[1]+4), color)
        self.parent.neo.write()

