from time import sleep

class Layout:
    def __init__(self, kwargs):
        self.parent = kwargs["parent"]
        self.border = kwargs["border"] # ((x,y)(x,y))
        if not self.isValid(kwargs["req_border"]):
            raise ValueError("Invalid layout boundaries")

    def isValid(self, reqBorder):
        (x1, y1), (x2, y2) = self.border
        if x1 < 0 or y1 < 0:
            return False
        if x2 > self.parent.length or y2 > self.parent.height:
            return False
        if x2 - x1 > reqBorder[0] or y2 - y1 > reqBorder[1]:
            return False
        return True
    
    def isInArea(self, foreignBorder):
        (ax1, ay1), (ax2, ay2) = self.border
        (bx1, by1), (bx2, by2) = foreignBorder
        return (ax1 < bx2 and ax2 > bx1 and ay1 < by2 and ay2 > by1)

    def clean(self):
        for x in range(self.border[0][0], self.border[1][0]):
            for y in range(self.border[0][1], self.border[1][1]):
                self.parent.setPixelColor((x, y), (0, 0, 0))
    

class SevenSegment(Layout):
    LINES = [((1, 0), (2, 0)), ((0, 1), (0, 2)), ((3, 1), (3, 2)), ((1, 3), (2, 3)), ((0, 4), (0, 5)), ((3, 4), (3, 5)), ((1, 6), (2, 6))]

    NUMBERS = [(0, 1, 2, 4, 5, 6), (2, 5), (0, 2, 3, 4, 6), (0, 2, 3, 5, 6), (1, 3, 5, 2), (0, 1, 3, 5, 6), (0, 1, 3, 4, 5, 6), (0, 2, 5), (0, 1, 2, 3, 4, 5, 6), (0, 1, 2, 3, 5, 6)]

    def __init__(self, **kwargs): # len_digits, parent, start
        self.lengthDigits = kwargs["len_digits"]
        self.start = kwargs["start"]
        kwargs["req_border"] = (kwargs["len_digits"] * 5)-1, 7
        kwargs["border"] = (self.start[0], self.start[1]), (self.start[0]+(kwargs["req_border"][0]), self.start[1]+7)
        super().__init__(kwargs)

        self.currentNumber = None
        

    def setLineColor(self, digit: int, lineNum: int, color: tuple):
        lineCoords = SevenSegment.LINES[lineNum]
        start = (digit * 5) + self.start[0]
        self.parent.setPixelColor(
            (lineCoords[0][0] + start, lineCoords[0][1] + self.start[1]), color
        )
        self.parent.setPixelColor(
            (lineCoords[1][0] + start, lineCoords[1][1] + self.start[1]), color
        )

    def drawDigit(self, digit: int, value: int, color: tuple):
        valueSequence = SevenSegment.NUMBERS[value]
        for num in valueSequence:
            self.setLineColor(digit, num, color)

    def drawNumber(self, value: str, color: str, write=False, force=False):
        if self.currentNumber == value or len(value) > self.lengthDigits:
            if not force:
                return
        self.currentNumber = value
        for i in range(len(value)):
            val = int(value[i]) if value != "00" else 0
            offset = self.lengthDigits - len(value)
            self.drawDigit(i + offset, val, color)

        if write: self.parent.neo.write()
    
    def flashNumber(self, num: int, color: tuple, delay: float, reps: int):
        for i in range(reps):
            self.clean()
            self.parent.neo.write()
            sleep(delay)
            self.drawNumber(num, color, write=True, force=True)
            sleep(delay)

class SSDivider(Layout):
    def __init__(self, **kwargs): # start
        kwargs["req_border"] = 1, 7
        self.start = kwargs["start"]
        kwargs["border"] = (self.start[0], self.start[1]), (self.start[0]+kwargs["req_border"][0], self.start[1]+kwargs["req_border"][1])
        super().__init__(kwargs)

    def draw(self, color, write=True):
        self.parent.setPixelColor((self.start[0], self.start[1]+2), color)
        self.parent.setPixelColor((self.start[0], self.start[1]+4), color)
        self.parent.neo.write()

