import time

class Timer:
    def __init__(self, cooldown):
        self.cooldown = cooldown
        self.lastActive = -cooldown*1000
    
    def check(self):
        current = time.ticks_ms()
        if current - self.cooldown*1000 > self.lastActive:
            self.lastActive = current
            return True
        return False

