from machine import Pin
import neopixel
import NP_MatrixCustom as npmc
from time import sleep

class Matrix:
    def __init__(self, pin, length, height):
        self.length = length
        self.height = height
        self.pixels = length * height
        self.pinis = Pin(pin, Pin.OUT)
        self.neo = neopixel.NeoPixel(self.pinis, self.pixels)
        self.currentNumber = None

        self.layouts = {}

    def getPixelNumber(self, x, y):
        length = y * self.length
        pos = length + x
        return pos

    def setPixelColor(self, pos: tuple, color):
        pos = self.getPixelNumber(pos[0], pos[1])
        self.neo[pos] = color

    def addLayout(self, name, layout):
        for key in self.layouts.keys():
            if self.layouts[key].isInArea(layout.border):
                raise Exception(f"Layout overlap - {name} is in the area of {key}")
        self.layouts[name] = layout
        return self.layouts[name]

    def createLayout(self, name, layoutType, **kwargs):
        layoutClass = getattr(npmc, layoutType)
        kwargs["parent"] = self
        layout = layoutClass(**kwargs)

        for key in self.layouts.keys():
            if self.layouts[key].isInArea(layout.border):
                raise Exception(f"Layout overlap - {name} is in the area of {key}")

        self.layouts[name] = layout
        return self.layouts[name]

    def applyToSelect(self, names, function):
        for key in self.layouts.keys():
            layout = self.layouts[key]

            if key in names:
                getattr(layout, function)()

    def applyByType(self, layoutType, function):
        layoutClass = getattr(npmc, layoutType)

        for key in self.layouts.keys():
            layout = self.layouts[key]

            if isinstance(layout, layoutClass):
                getattr(layout, function)()

    def applyToAll(self, function):
        for key in self.layouts.keys():
            layout = self.layouts[key]
            getattr(layout, function)()
            

