from machine import Pin
import neopixel

class Matrix:
    def __init__(self, pin, length, height):
        self.length = length
        self.height = height
        self.pixels = length * height
        self.pinis = Pin(pin, Pin.OUT)
        self.neo = neopixel.NeoPixel(self.pinis, self.pixels)
        self.currentNumber = None

        self.layouts = {}

    def getPixelNumber(self, x, y):
        length = y * self.length
        pos = length + x
        return pos

    def setPixelColor(self, pos: tuple, color):
        pos = self.getPixelNumber(pos[0], pos[1])
        self.neo[pos] = color

    def addLayout(self, name, layout):
        for key in self.layouts.keys():
            if self.layouts[key].isInArea(layout.border):
                return None
        self.layouts[name] = layout
        return self.layouts[name]

