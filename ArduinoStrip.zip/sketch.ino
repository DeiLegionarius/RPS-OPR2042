#include <Adafruit_NeoPixel.h>

#define STRIP_PIN 2
#define NUM_PIXELS 10

Adafruit_NeoPixel neo(NUM_PIXELS, STRIP_PIN, NEO_GRB + NEO_KHZ800);

int prejsnja = 5000;

void clean(Adafruit_NeoPixel &strip) {
  for (int i = 0; i < NUM_PIXELS; i++) {
    strip.setPixelColor(i, strip.Color(0, 0, 0));
  }
}



void setup() {
  pinMode(A0, INPUT);

  for (int x = 3; x < 7; x++) {
    pinMode(x, OUTPUT);
  }

  Serial.begin(9600);
  neo.begin();

}

void loop() {
  int pot = analogRead(A0);

  int mapirana = map(pot, 0, 1023, 0, NUM_PIXELS);

  if (pot != prejsnja){
    prejsnja = pot;

    clean(neo);
    for (int i = 0; i < mapirana; i++) {
      neo.setPixelColor(i, neo.Color(255, 255, 255));
    }
    neo.show();
    
    int ledice = map(pot, 0, 1023, 2, 6);
    for (int x = 3; x < 7; x++) {
      digitalWrite(x, LOW);
      if (x <= ledice) {
        digitalWrite(x, HIGH);
      }
    }

    Serial.println("vrednost:" + String(mapirana));
  };

}
